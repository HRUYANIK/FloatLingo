# FloatLingo – AI Destekli Ekran Çeviri Uygulaması

> Android üzerinde çalışan, ekran üzerinde sürüklenebilir 2D karakter ile gerçek zamanlı ekran çevirisi yapan production-ready uygulama.

---

## 📋 İçindekiler

1. [Proje Yapısı](#proje-yapısı)
2. [Mimari](#mimari)
3. [Kurulum Gereksinimleri](#kurulum-gereksinimleri)
4. [Adım Adım Kurulum](#adım-adım-kurulum)
5. [APK Oluşturma](#apk-oluşturma)
6. [Özellikler](#özellikler)
7. [Teknik Detaylar](#teknik-detaylar)
8. [Sorun Giderme](#sorun-giderme)

---

## 📁 Proje Yapısı

```
FloatLingo/
├── app/
│   ├── src/main/
│   │   ├── kotlin/com/floatlingo/
│   │   │   ├── FloatLingoApp.kt                  # Application sınıfı (Hilt)
│   │   │   ├── core/
│   │   │   │   ├── base/
│   │   │   │   │   └── BaseViewModel.kt           # Temel ViewModel
│   │   │   │   ├── di/
│   │   │   │   │   ├── AppModule.kt               # Hilt modülü (DB, DAO)
│   │   │   │   │   └── RepositoryModule.kt        # Repository bindings
│   │   │   │   └── utils/
│   │   │   │       ├── Constants.kt               # Uygulama sabitleri
│   │   │   │       ├── Extensions.kt              # Kotlin uzantı fonksiyonları
│   │   │   │       └── Resource.kt                # UI state sealed class
│   │   │   ├── data/
│   │   │   │   ├── model/
│   │   │   │   │   └── Models.kt                  # Tüm data modelleri
│   │   │   │   ├── repository/
│   │   │   │   │   ├── TranslationRepository.kt   # Çeviri interface + impl
│   │   │   │   │   ├── OcrRepository.kt           # OCR interface + impl
│   │   │   │   │   └── SettingsRepository.kt      # Ayarlar interface + impl
│   │   │   │   └── source/
│   │   │   │       └── local/
│   │   │   │           ├── FloatLingoDatabase.kt  # Room veritabanı
│   │   │   │           ├── TranslationCacheDao.kt # Cache DAO
│   │   │   │           └── AppPreferences.kt      # DataStore preferences
│   │   │   ├── feature/
│   │   │   │   ├── floating/
│   │   │   │   │   └── FloatingCharacterService.kt # Ana floating service
│   │   │   │   ├── translation/
│   │   │   │   │   ├── TranslationOverlayManager.kt
│   │   │   │   │   ├── TranslationService.kt
│   │   │   │   │   ├── SimpleTranslateFragment.kt
│   │   │   │   │   ├── SimpleTranslateViewModel.kt
│   │   │   │   │   └── LanguagePickerDialog.kt
│   │   │   │   ├── permissions/
│   │   │   │   │   └── PermissionSetupActivity.kt
│   │   │   │   └── settings/
│   │   │   │       ├── SettingsActivity.kt
│   │   │   │       └── SettingsViewModel.kt
│   │   │   └── ui/
│   │   │       ├── MainActivity.kt
│   │   │       ├── MainViewModel.kt
│   │   │       └── HomeFragment.kt
│   │   ├── res/
│   │   │   ├── anim/          # Karakter animasyonları
│   │   │   ├── drawable/      # Vector ikonlar, arka planlar
│   │   │   ├── layout/        # XML layout dosyaları
│   │   │   ├── menu/          # Menü tanımları
│   │   │   ├── values/        # String, color, theme
│   │   │   └── xml/           # Backup kuralları
│   │   └── AndroidManifest.xml
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── gradle/
│   └── libs.versions.toml     # Version catalog
├── build.gradle.kts
└── settings.gradle.kts
```

---

## 🏗 Mimari

```
┌─────────────────────────────────────────────────────────┐
│                        UI Layer                          │
│  MainActivity  │  Fragments  │  FloatingCharacterService │
├─────────────────────────────────────────────────────────┤
│                    ViewModel Layer                        │
│  MainViewModel │ SimpleTranslateVM │ SettingsViewModel   │
├─────────────────────────────────────────────────────────┤
│                   Repository Layer                        │
│  TranslationRepo │ OcrRepository │ SettingsRepository   │
├─────────────────────────────────────────────────────────┤
│                    Data Sources                           │
│  ML Kit OCR  │  ML Kit Translation  │  Room DB           │
│  MediaProjection API  │  DataStore Preferences           │
└─────────────────────────────────────────────────────────┘
```

**Kullanılan Patternler:**
- MVVM Architecture
- Repository Pattern
- Dependency Injection (Hilt)
- Coroutines + StateFlow
- Sealed Class (Resource<T>) ile UI state yönetimi

---

## ⚙️ Kurulum Gereksinimleri

### Yazılım Gereksinimleri
| Araç | Minimum Versiyon |
|------|-----------------|
| Android Studio | Hedgehog (2023.1.1) veya üstü |
| JDK | 17 |
| Android SDK | API 35 (Android 15) |
| Min SDK | API 26 (Android 8.0) |
| Kotlin | 1.9.23 |
| AGP | 8.3.2 |

### Donanım Gereksinimleri (Test Cihazı)
- Android 8.0 (API 26) veya üstü
- Minimum 3 GB RAM
- İnternet bağlantısı (ilk model indirme için)

---

## 🚀 Adım Adım Kurulum

### 1. Projeyi Klonlayın / Açın

```bash
# Projeyi Android Studio'da açın
File > Open > FloatLingo klasörünü seçin
```

### 2. Gradle Sync Yapın

Android Studio açıldıktan sonra:
```
File > Sync Project with Gradle Files
```
veya toolbar'daki **🔄 Sync** butonuna tıklayın.

### 3. SDK'yı Yapılandırın

```
File > Project Structure > SDK Location
```
- Android SDK konumunu doğrulayın
- JDK 17 seçili olduğundan emin olun

### 4. Google ML Kit'i Etkinleştirin

ML Kit otomatik olarak Maven Central'dan indirilir. İnternet bağlantınız olduğundan emin olun.

> **Not:** ML Kit'in çeviri modelleri (~30-50 MB) ilk kullanımda otomatik indirilir. Offline kullanım için Ayarlar > Dil İndirme bölümünden önceden indirebilirsiniz.

### 5. Cihaz / Emülatör Ayarları

**Gerçek Cihaz (Önerilen):**
```
Ayarlar > Geliştirici Seçenekleri > USB Hata Ayıklama: Açık
```

**Emülatör:**
- API 26+ emülatör oluşturun
- RAM: 4 GB (önerilen)
- `SYSTEM_ALERT_WINDOW` emülatörde bazı kısıtlamalar olabilir → gerçek cihaz tercih edilir

### 6. Uygulamayı Çalıştırın

```
Run > Run 'app'  (Shift + F10)
```

---

## 📦 APK Oluşturma

### Debug APK

```bash
# Terminal'de proje kök dizininde:
./gradlew assembleDebug

# APK konumu:
# app/build/outputs/apk/debug/app-debug.apk
```

### Release APK

#### Keystore Oluşturma (İlk Kez)

```bash
keytool -genkey -v \
  -keystore floatlingo-release.jks \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -alias floatlingo
```

#### app/build.gradle.kts'e Signing Config Ekleyin

```kotlin
android {
    signingConfigs {
        create("release") {
            storeFile = file("../floatlingo-release.jks")
            storePassword = "YOUR_STORE_PASSWORD"
            keyAlias = "floatlingo"
            keyPassword = "YOUR_KEY_PASSWORD"
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            // ...
        }
    }
}
```

#### Release APK Oluşturma

```bash
./gradlew assembleRelease

# APK konumu:
# app/build/outputs/apk/release/app-release.apk
```

#### Android App Bundle (Google Play için)

```bash
./gradlew bundleRelease

# AAB konumu:
# app/build/outputs/bundle/release/app-release.aab
```

---

## ✨ Özellikler

### 🤖 Floating Karakter
- Diğer uygulamaların üstünde gösterilir (`TYPE_APPLICATION_OVERLAY`)
- Sürükle-bırak ile ekranın istenen yerine taşınabilir
- **Idle Animasyonlar:** Göz kırpma, sağa/sola bakma, hafif zıplama
- Tıklandığında el sallama animasyonu + popup menü açılır
- 3 farklı karakter: Robot 🤖, Kedi 🐱, Baykuş 🦉

### ⚡ Anlık Çeviri
- MediaProjection API ile ekran görüntüsü alınır
- ML Kit Text Recognition ile OCR yapılır
- ML Kit Translation ile hedef dile çevrilir
- Overlay olarak ekrana yazılır (8 saniye sonra otomatik kapanır)

### 🔄 Sürekli Çeviri (Batarya Optimize)
- Her **2 saniyede bir** çalışır (sürekli değil)
- **Akıllı cache:** Aynı metin tekrar çevrilmez (Levenshtein benzerlik algoritması)
- Yalnızca %85 eşik altında değişen metinler çevrilir
- Pil tüketimini minimize eder

### 💬 Sade Çeviri
- Metin ile çeviri (debounce'lu otomatik çeviri)
- Ses ile çeviri (Android SpeechRecognizer)
- Dil değiştirme (swap)
- Sonucu panoya kopyalama

### ⚙️ Ayarlar
- Kaynak/hedef dil seçimi (60+ dil)
- Offline dil indirme
- Karakter değiştirme
- Font boyutu (12-30sp)
- Overlay opaklığı
- Tema (Açık/Koyu/Sistem)

---

## 🔧 Teknik Detaylar

### Bağımlılıklar

| Kategori | Kütüphane | Versiyon |
|----------|-----------|---------|
| DI | Hilt | 2.51.1 |
| DB | Room | 2.6.1 |
| OCR | ML Kit Text Recognition | 16.0.1 |
| Çeviri | ML Kit Translate | 17.0.2 |
| Coroutines | KotlinX Coroutines | 1.8.1 |
| Network | Retrofit + OkHttp | 2.11.0 / 4.12.0 |
| Preferences | DataStore | 1.1.1 |
| Loglama | Timber | 5.0.1 |

### İzinler Açıklaması

| İzin | Amaç | Zorunlu |
|------|------|---------|
| `SYSTEM_ALERT_WINDOW` | Floating karakter | ✅ |
| `FOREGROUND_SERVICE` | Arka plan servisi | ✅ |
| `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Ekran yakalama | ✅ |
| `RECORD_AUDIO` | Sesli çeviri | ❌ (opsiyonel) |
| `INTERNET` | Çeviri modeli güncelleme | ✅ |

### Cache Mekanizması

```
Kullanıcı ekrana bakar
      ↓
OCR ile metin çıkarılır
      ↓
Önceki metinle karşılaştırılır (Levenshtein)
      ↓
Benzerlik > %85? → ATLA (batarya tasarrufu)
      ↓
Room DB'de cache kontrol edilir
      ↓
Cache'de var? → Hemen göster
      ↓
ML Kit ile çevir → Cache'e kaydet → Göster
```

---

## 🐛 Sorun Giderme

### "Cannot draw overlays" Hatası
```
Ayarlar > Uygulamalar > FloatLingo > 
Diğer uygulamaların üzerinde görüntüle > Açık
```

### MediaProjection İzni Verilmiyor
- Android 14+ cihazlarda her oturum için izin tekrar istenir
- Emülatörde çalışmıyor olabilir → gerçek cihaz kullanın

### ML Kit Modeli İndirilemiyor
- İnternet bağlantısını kontrol edin
- Google Play Services güncel olduğundan emin olun

### Çeviri Çalışmıyor
```kotlin
// TranslationRepositoryImpl'de log'ları kontrol edin:
Timber.tag("Translation").d("...")
// Logcat filtrelemesi: tag:Translation
```

### Build Hatası: "Duplicate class"
```bash
./gradlew clean
./gradlew assembleDebug
```

### Hilt Compile Hatası
```bash
./gradlew kaptDebugKotlin --stacktrace
```

---

## 📝 Geliştirme Notları

### Yeni Karakter Ekleme
1. `res/drawable/ic_NEW_character.xml` oluşturun
2. `Constants.kt`'ye `CHARACTER_NEW = "new"` ekleyin
3. `SettingsActivity.kt`'ye yeni card ekleyin
4. `FloatingCharacterService.kt`'de karakter seçimini güncelleyin

### Yeni Dil Ekleme
ML Kit desteklediği sürece `TranslationRepositoryImpl.getSupportedLanguages()` listesine ekleyin.

### Performans İpuçları
- `CONTINUOUS_INTERVAL_MS` değerini artırarak batarya tasarrufu yapabilirsiniz
- `OCR_TEXT_SIMILARITY_THRESHOLD` değerini artırarak daha az çeviri yapılır
- `TRANSLATION_CACHE_SIZE` değerini artırarak daha fazla çeviri cache'lenir

---

## 📄 Lisans

Bu proje private/proprietary lisans altındadır.

---

*FloatLingo v1.0.0 – Production Ready*
