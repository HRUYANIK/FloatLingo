package com.floatlingo.feature.floating

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.floatlingo.R
import com.floatlingo.core.utils.Constants
import com.floatlingo.core.utils.canDrawOverlays
import com.floatlingo.core.utils.downscale
import com.floatlingo.core.utils.getScreenHeight
import com.floatlingo.core.utils.getScreenWidth
import com.floatlingo.data.model.AppSettings
import com.floatlingo.data.model.TranslationMode
import com.floatlingo.data.repository.OcrRepository
import com.floatlingo.data.repository.SettingsRepository
import com.floatlingo.data.repository.TranslationRepository
import com.floatlingo.feature.translation.TranslationOverlayManager
import com.floatlingo.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import timber.log.Timber
import javax.inject.Inject
import kotlin.math.abs

@AndroidEntryPoint
class FloatingCharacterService : LifecycleService() {

    @Inject lateinit var translationRepository: TranslationRepository
    @Inject lateinit var ocrRepository: OcrRepository
    @Inject lateinit var settingsRepository: SettingsRepository

    private lateinit var windowManager: WindowManager
    private lateinit var characterView: View
    private lateinit var popupMenuView: View
    private var translationOverlayManager: TranslationOverlayManager? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var continuousTranslationJob: Job? = null
    private var idleAnimationJob: Job? = null
    private var lastOcrText = ""

    private var currentSettings = AppSettings()

    private val layoutParams = WindowManager.LayoutParams().apply {
        type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        format = PixelFormat.TRANSLUCENT
        gravity = Gravity.TOP or Gravity.START
        width = WindowManager.LayoutParams.WRAP_CONTENT
        height = WindowManager.LayoutParams.WRAP_CONTENT
        x = 100
        y = 300
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, FloatingCharacterService::class.java).apply {
                action = Constants.ACTION_START_FLOATING
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingCharacterService::class.java).apply {
                action = Constants.ACTION_STOP_FLOATING
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(Constants.FLOATING_SERVICE_NOTIFICATION_ID, buildNotification())

        lifecycleScope.launch {
            settingsRepository.getAppSettings().collect { settings ->
                currentSettings = settings
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            Constants.ACTION_START_FLOATING -> showFloatingCharacter()
            Constants.ACTION_STOP_FLOATING -> stopSelf()
            Constants.ACTION_INSTANT_TRANSLATE -> triggerInstantTranslation()
            Constants.ACTION_CONTINUOUS_TRANSLATE -> startContinuousTranslation()
            Constants.ACTION_STOP_CONTINUOUS -> stopContinuousTranslation()
        }

        // Handle MediaProjection data
        val resultCode = intent?.getIntExtra(Constants.MEDIA_PROJECTION_RESULT_CODE, Activity.RESULT_CANCELED)
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(Constants.MEDIA_PROJECTION_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(Constants.MEDIA_PROJECTION_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }

        return START_STICKY
    }

    private fun showFloatingCharacter() {
        if (!canDrawOverlays()) {
            Timber.w("Cannot draw overlays - permission not granted")
            return
        }
        if (::characterView.isInitialized) return

        setupCharacterView()
        setupIdleAnimations()
        translationOverlayManager = TranslationOverlayManager(this, windowManager)
    }

    private fun setupCharacterView() {
        val inflater = LayoutInflater.from(this)
        characterView = inflater.inflate(R.layout.view_floating_character, null)
        popupMenuView = inflater.inflate(R.layout.view_popup_menu, null)

        setupDragBehavior()
        setupCharacterClickListener()
        setupPopupMenuListeners()

        try {
            windowManager.addView(characterView, layoutParams)
        } catch (e: Exception) {
            Timber.e(e, "Failed to add floating character view")
        }
    }

    private fun setupDragBehavior() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var touchStartTime = 0L

        characterView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    touchStartTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        isDragging = true
                        dismissPopupMenu()
                    }
                    if (isDragging) {
                        layoutParams.x = (initialX + dx).toInt().coerceIn(0, getScreenWidth() - characterView.width)
                        layoutParams.y = (initialY + dy).toInt().coerceIn(0, getScreenHeight() - characterView.height)
                        try {
                            windowManager.updateViewLayout(characterView, layoutParams)
                        } catch (e: Exception) {
                            Timber.e(e, "Failed to update character position")
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val elapsedTime = System.currentTimeMillis() - touchStartTime
                    if (!isDragging && elapsedTime < 300) {
                        onCharacterClicked()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun onCharacterClicked() {
        playWaveAnimation()
        togglePopupMenu()
    }

    private fun playWaveAnimation() {
        val characterImageView = characterView.findViewById<ImageView>(R.id.iv_character)
        val waveAnim = AnimationUtils.loadAnimation(this, R.anim.character_wave)
        characterImageView?.startAnimation(waveAnim)
    }

    private fun togglePopupMenu() {
        if (popupMenuView.parent != null) {
            dismissPopupMenu()
        } else {
            showPopupMenu()
        }
    }

    private fun showPopupMenu() {
        val menuParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            format = PixelFormat.TRANSLUCENT
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            x = layoutParams.x + characterView.width + 8
            y = layoutParams.y
        }

        try {
            windowManager.addView(popupMenuView, menuParams)
            val slideIn = AnimationUtils.loadAnimation(this, R.anim.slide_in_right)
            popupMenuView.startAnimation(slideIn)
        } catch (e: Exception) {
            Timber.e(e, "Failed to show popup menu")
        }
    }

    private fun dismissPopupMenu() {
        if (popupMenuView.parent != null) {
            try {
                val slideOut = AnimationUtils.loadAnimation(this, R.anim.slide_out_right)
                popupMenuView.startAnimation(slideOut)
                Handler(Looper.getMainLooper()).postDelayed({
                    try {
                        windowManager.removeView(popupMenuView)
                    } catch (e: Exception) { /* ignore */ }
                }, 200)
            } catch (e: Exception) {
                try { windowManager.removeView(popupMenuView) } catch (e2: Exception) { /* ignore */ }
            }
        }
    }

    private fun setupPopupMenuListeners() {
        popupMenuView.findViewById<View>(R.id.btn_instant_translate)?.setOnClickListener {
            dismissPopupMenu()
            triggerInstantTranslation()
        }
        popupMenuView.findViewById<View>(R.id.btn_continuous_translate)?.setOnClickListener {
            dismissPopupMenu()
            if (continuousTranslationJob?.isActive == true) {
                stopContinuousTranslation()
            } else {
                startContinuousTranslation()
            }
        }
        popupMenuView.findViewById<View>(R.id.btn_simple_translate)?.setOnClickListener {
            dismissPopupMenu()
            openSimpleTranslation()
        }
    }

    private fun setupCharacterClickListener() {
        // Already handled in touch listener
    }

    private fun setupIdleAnimations() {
        idleAnimationJob = lifecycleScope.launch {
            val characterImageView = characterView.findViewById<ImageView>(R.id.iv_character)
            while (isActive) {
                val delayMs = (3000L..8000L).random()
                delay(delayMs)
                if (!isActive) break

                val animRes = listOf(
                    R.anim.character_blink,
                    R.anim.character_look_left,
                    R.anim.character_look_right,
                    R.anim.character_idle_bounce
                ).random()

                withContext(Dispatchers.Main) {
                    try {
                        val anim = AnimationUtils.loadAnimation(this@FloatingCharacterService, animRes)
                        characterImageView?.startAnimation(anim)
                    } catch (e: Exception) {
                        Timber.e(e, "Failed to play idle animation")
                    }
                }
            }
        }
    }

    private fun triggerInstantTranslation() {
        lifecycleScope.launch {
            val bitmap = captureScreen() ?: run {
                Timber.w("Failed to capture screen for instant translation")
                return@launch
            }
            processScreenCapture(bitmap, TranslationMode.INSTANT)
        }
    }

    private fun startContinuousTranslation() {
        if (continuousTranslationJob?.isActive == true) return

        continuousTranslationJob = lifecycleScope.launch {
            translationOverlayManager?.showContinuousIndicator(true)
            while (isActive) {
                val bitmap = captureScreen()
                if (bitmap != null) {
                    processScreenCapture(bitmap, TranslationMode.CONTINUOUS)
                }
                delay(Constants.CONTINUOUS_INTERVAL_MS)
            }
        }
    }

    private fun stopContinuousTranslation() {
        continuousTranslationJob?.cancel()
        continuousTranslationJob = null
        translationOverlayManager?.showContinuousIndicator(false)
        translationOverlayManager?.hideTranslationOverlay()
    }

    private suspend fun captureScreen(): Bitmap? {
        return try {
            val image = imageReader?.acquireLatestImage() ?: return null
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * getScreenWidth()

            val bitmap = Bitmap.createBitmap(
                getScreenWidth() + rowPadding / pixelStride,
                getScreenHeight(),
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)
            image.close()

            bitmap.downscale()
        } catch (e: Exception) {
            Timber.e(e, "Screen capture failed")
            null
        }
    }

    private suspend fun processScreenCapture(bitmap: Bitmap, mode: TranslationMode) {
        val ocrResult = ocrRepository.extractText(bitmap)
        if (ocrResult.isError || ocrResult.getOrNull()?.text.isNullOrBlank()) return

        val extractedText = ocrResult.getOrNull()?.text ?: return

        // For continuous mode: skip if text hasn't changed significantly
        if (mode == TranslationMode.CONTINUOUS) {
            val similarity = ocrRepository.calculateTextSimilarity(lastOcrText, extractedText)
            if (similarity > Constants.OCR_TEXT_SIMILARITY_THRESHOLD) {
                Timber.d("Skipping translation - text similarity: $similarity")
                return
            }
        }

        lastOcrText = extractedText

        val settings = settingsRepository.getAppSettings().first()
        val translationResult = translationRepository.translate(
            com.floatlingo.data.model.TranslationRequest(
                text = extractedText,
                sourceLanguage = settings.sourceLanguage,
                targetLanguage = settings.targetLanguage
            )
        )

        translationResult.getOrNull()?.let { result ->
            withContext(Dispatchers.Main) {
                translationOverlayManager?.showTranslation(
                    originalText = result.originalText,
                    translatedText = result.translatedText,
                    mode = mode
                )
            }
        }
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        try {
            val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)

            val screenWidth = getScreenWidth()
            val screenHeight = getScreenHeight()
            val dpi = resources.displayMetrics.densityDpi

            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "FloatLingoCapture",
                screenWidth, screenHeight, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, null
            )
            Timber.d("MediaProjection setup complete")
        } catch (e: Exception) {
            Timber.e(e, "Failed to setup MediaProjection")
        }
    }

    private fun openSimpleTranslation() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("open_tab", "simple_translate")
        }
        startActivity(intent)
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingCharacterService::class.java).apply {
                action = Constants.ACTION_STOP_FLOATING
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, Constants.FLOATING_SERVICE_CHANNEL_ID)
            .setContentTitle("FloatLingo Aktif")
            .setContentText("Çeviri asistanı çalışıyor")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openAppIntent)
            .addAction(R.drawable.ic_stop, "Durdur", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.FLOATING_SERVICE_CHANNEL_ID,
                Constants.FLOATING_SERVICE_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "FloatLingo floating character service"
                setShowBadge(false)
            }
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        idleAnimationJob?.cancel()
        continuousTranslationJob?.cancel()

        // Clean up views
        try { if (::characterView.isInitialized) windowManager.removeView(characterView) } catch (e: Exception) { /* ignore */ }
        try { if (popupMenuView.parent != null) windowManager.removeView(popupMenuView) } catch (e: Exception) { /* ignore */ }

        // Clean up MediaProjection
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()

        translationOverlayManager?.cleanup()
    }
}
