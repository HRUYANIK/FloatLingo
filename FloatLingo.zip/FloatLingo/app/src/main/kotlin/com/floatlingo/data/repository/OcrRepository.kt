package com.floatlingo.data.repository

import android.graphics.Bitmap
import com.floatlingo.core.utils.Resource
import com.floatlingo.data.model.OcrResult
import com.floatlingo.data.model.TextBlock
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

interface OcrRepository {
    suspend fun extractText(bitmap: Bitmap): Resource<OcrResult>
    fun calculateTextSimilarity(text1: String, text2: String): Float
}

@Singleton
class OcrRepositoryImpl @Inject constructor() : OcrRepository {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override suspend fun extractText(bitmap: Bitmap): Resource<OcrResult> {
        return try {
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            val result = recognizer.process(inputImage).await()

            val fullText = result.text
            if (fullText.isBlank()) {
                return Resource.Success(OcrResult(text = "", confidence = 0f))
            }

            val textBlocks = result.textBlocks.flatMap { block ->
                block.lines.map { line ->
                    val boundingBox = line.boundingBox
                    TextBlock(
                        text = line.text,
                        left = boundingBox?.left ?: 0,
                        top = boundingBox?.top ?: 0,
                        right = boundingBox?.right ?: 0,
                        bottom = boundingBox?.bottom ?: 0
                    )
                }
            }

            val avgConfidence = result.textBlocks
                .flatMap { it.lines }
                .flatMap { it.elements }
                .mapNotNull { it.confidence }
                .average()
                .toFloat()
                .let { if (it.isNaN()) 0.8f else it }

            Resource.Success(
                OcrResult(
                    text = fullText,
                    confidence = avgConfidence,
                    boundingBoxes = textBlocks
                )
            )
        } catch (e: Exception) {
            Timber.e(e, "OCR extraction failed")
            Resource.Error("OCR failed: ${e.localizedMessage}", e)
        }
    }

    override fun calculateTextSimilarity(text1: String, text2: String): Float {
        if (text1.isBlank() && text2.isBlank()) return 1f
        if (text1.isBlank() || text2.isBlank()) return 0f
        if (text1 == text2) return 1f

        val maxLen = maxOf(text1.length, text2.length).toFloat()
        val editDistance = levenshteinDistance(text1, text2)
        return 1f - (editDistance / maxLen)
    }

    private fun levenshteinDistance(s1: String, s2: String): Int {
        val m = s1.length
        val n = s2.length
        val dp = Array(m + 1) { IntArray(n + 1) }

        for (i in 0..m) dp[i][0] = i
        for (j in 0..n) dp[0][j] = j

        for (i in 1..m) {
            for (j in 1..n) {
                dp[i][j] = if (s1[i - 1] == s2[j - 1]) {
                    dp[i - 1][j - 1]
                } else {
                    1 + minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
                }
            }
        }
        return dp[m][n]
    }
}
