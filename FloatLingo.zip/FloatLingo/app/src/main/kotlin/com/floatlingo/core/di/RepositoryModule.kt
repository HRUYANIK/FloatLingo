package com.floatlingo.core.di

import com.floatlingo.data.repository.SettingsRepositoryImpl
import com.floatlingo.data.repository.TranslationRepositoryImpl
import com.floatlingo.data.repository.OcrRepositoryImpl
import com.floatlingo.data.repository.SettingsRepository
import com.floatlingo.data.repository.TranslationRepository
import com.floatlingo.data.repository.OcrRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindTranslationRepository(
        impl: TranslationRepositoryImpl
    ): TranslationRepository

    @Binds
    @Singleton
    abstract fun bindOcrRepository(
        impl: OcrRepositoryImpl
    ): OcrRepository

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(
        impl: SettingsRepositoryImpl
    ): SettingsRepository
}
