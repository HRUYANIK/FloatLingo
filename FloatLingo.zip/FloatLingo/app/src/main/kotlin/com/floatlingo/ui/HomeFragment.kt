package com.floatlingo.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.floatlingo.databinding.FragmentHomeBinding
import com.floatlingo.feature.permissions.PermissionSetupActivity
import com.floatlingo.core.utils.canDrawOverlays
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun setupUI() {
        binding.cardPermissions.setOnClickListener {
            startActivity(Intent(requireContext(), PermissionSetupActivity::class.java))
        }
    }

    private fun updatePermissionStatus() {
        val overlayGranted = requireContext().canDrawOverlays()
        binding.tvPermissionStatus.text = if (overlayGranted) {
            "✓ Tüm izinler verildi - Asistanı başlatabilirsiniz"
        } else {
            "⚠ Bazı izinler eksik - İzin ayarlarına gidin"
        }
        binding.cardPermissions.visibility = if (overlayGranted) View.GONE else View.VISIBLE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
