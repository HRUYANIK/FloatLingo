package com.floatlingo.feature.translation

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.floatlingo.R
import com.floatlingo.databinding.FragmentSimpleTranslateBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.Locale

@AndroidEntryPoint
class SimpleTranslateFragment : Fragment() {

    private var _binding: FragmentSimpleTranslateBinding? = null
    private val binding get() = _binding!!

    private val viewModel: SimpleTranslateViewModel by viewModels()
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoiceInput()
        else Toast.makeText(context, getString(R.string.mic_permission_denied), Toast.LENGTH_SHORT).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSimpleTranslateBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        // Text input watcher with debounce
        var debounceJob: kotlinx.coroutines.Job? = null
        binding.etInputText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                debounceJob?.cancel()
                debounceJob = lifecycleScope.launch {
                    kotlinx.coroutines.delay(600)
                    val text = s?.toString()?.trim() ?: ""
                    if (text.isNotBlank()) viewModel.translate(text)
                    else viewModel.clearTranslation()
                }
            }
        })

        // Translate button
        binding.btnTranslate.setOnClickListener {
            val text = binding.etInputText.text.toString().trim()
            if (text.isNotBlank()) viewModel.translate(text)
        }

        // Voice input button
        binding.btnVoiceInput.setOnClickListener {
            if (isListening) stopVoiceInput()
            else checkMicPermissionAndStart()
        }

        // Swap languages
        binding.btnSwapLanguages.setOnClickListener {
            viewModel.swapLanguages()
        }

        // Clear
        binding.btnClearInput.setOnClickListener {
            binding.etInputText.text?.clear()
            viewModel.clearTranslation()
        }

        // Copy result
        binding.btnCopyTranslation.setOnClickListener {
            val text = binding.tvTranslationResult.text.toString()
            if (text.isNotBlank()) {
                val clipboard = requireContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("translation", text))
                Toast.makeText(context, getString(R.string.copied_to_clipboard), Toast.LENGTH_SHORT).show()
            }
        }

        // Source language selector
        binding.tvSourceLanguage.setOnClickListener {
            showLanguagePicker(isSource = true)
        }

        // Target language selector
        binding.tvTargetLanguage.setOnClickListener {
            showLanguagePicker(isSource = false)
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.translationResult.collectLatest { result ->
                if (result != null) {
                    binding.tvTranslationResult.text = result.translatedText
                    binding.cardTranslationResult.visibility = View.VISIBLE
                } else {
                    binding.tvTranslationResult.text = ""
                    binding.cardTranslationResult.visibility = View.GONE
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.isLoading.collectLatest { loading ->
                binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
                binding.btnTranslate.isEnabled = !loading
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.errorMessage.collectLatest { error ->
                if (error != null) {
                    Toast.makeText(context, error, Toast.LENGTH_LONG).show()
                    viewModel.clearError()
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.sourceLanguage.collectLatest { lang ->
                binding.tvSourceLanguage.text = lang.uppercase()
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.targetLanguage.collectLatest { lang ->
                binding.tvTargetLanguage.text = lang.uppercase()
            }
        }
    }

    private fun checkMicPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) {
            startVoiceInput()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(requireContext())) {
            Toast.makeText(context, getString(R.string.speech_not_available), Toast.LENGTH_SHORT).show()
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(requireContext())
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                binding.btnVoiceInput.setImageResource(R.drawable.ic_mic_active)
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isListening = false
                binding.btnVoiceInput.setImageResource(R.drawable.ic_mic)
            }
            override fun onError(error: Int) {
                isListening = false
                binding.btnVoiceInput.setImageResource(R.drawable.ic_mic)
                Timber.e("Speech recognition error: $error")
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val recognizedText = matches[0]
                    binding.etInputText.setText(recognizedText)
                    viewModel.translate(recognizedText)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun stopVoiceInput() {
        speechRecognizer?.stopListening()
        isListening = false
        binding.btnVoiceInput.setImageResource(R.drawable.ic_mic)
    }

    private fun showLanguagePicker(isSource: Boolean) {
        val dialog = LanguagePickerDialog(
            onLanguageSelected = { code ->
                if (isSource) viewModel.updateSourceLanguage(code)
                else viewModel.updateTargetLanguage(code)
            }
        )
        dialog.show(childFragmentManager, "language_picker")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        speechRecognizer?.destroy()
        speechRecognizer = null
        _binding = null
    }
}
