package com.floatlingo.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class TranslationRequest(
    val text: String,
    val sourceLanguage: String,
    val targetLanguage: String
)

data class TranslationResult(
    val originalText: String,
    val translatedText: String,
    val sourceLanguage: String,
    val targetLanguage: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "translation_cache")
data class TranslationCacheEntity(
    @PrimaryKey
    val cacheKey: String,
    val originalText: String,
    val translatedText: String,
    val sourceLanguage: String,
    val targetLanguage: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class Language(
    val code: String,
    val displayName: String,
    val isDownloaded: Boolean = false,
    val isDownloading: Boolean = false
)

data class AppSettings(
    val sourceLanguage: String = "auto",
    val targetLanguage: String = "tr",
    val characterType: String = "robot",
    val fontSize: Float = 16f,
    val theme: String = "system",
    val overlayOpacity: Float = 0.9f
)

data class OcrResult(
    val text: String,
    val confidence: Float,
    val boundingBoxes: List<TextBlock> = emptyList()
)

data class TextBlock(
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
)

enum class TranslationMode {
    INSTANT, CONTINUOUS, SIMPLE
}

enum class CharacterState {
    IDLE, THINKING, CELEBRATING, WAVING, BLINKING, LOOKING_LEFT, LOOKING_RIGHT
}
