package com.floatlingo.data.repository

import com.floatlingo.core.utils.Constants
import com.floatlingo.core.utils.Resource
import com.floatlingo.data.model.Language
import com.floatlingo.data.model.TranslationCacheEntity
import com.floatlingo.data.model.TranslationRequest
import com.floatlingo.data.model.TranslationResult
import com.floatlingo.data.source.local.TranslationCacheDao
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TranslationRepositoryImpl @Inject constructor(
    private val cacheDao: TranslationCacheDao
) : TranslationRepository {

    // Cache of active translators to avoid recreating them
    private val translatorCache = mutableMapOf<String, com.google.mlkit.nl.translate.Translator>()

    override suspend fun translate(request: TranslationRequest): Resource<TranslationResult> {
        return try {
            // Check cache first
            val cached = getCachedTranslation(request.text, request.sourceLanguage, request.targetLanguage)
            if (cached != null) {
                Timber.d("Translation cache hit for: ${request.text.take(30)}")
                return Resource.Success(cached)
            }

            // Perform translation
            val translatedText = performTranslation(request)
            val result = TranslationResult(
                originalText = request.text,
                translatedText = translatedText,
                sourceLanguage = request.sourceLanguage,
                targetLanguage = request.targetLanguage
            )

            // Cache the result
            cacheTranslation(result)

            Resource.Success(result)
        } catch (e: Exception) {
            Timber.e(e, "Translation failed for text: ${request.text.take(50)}")
            Resource.Error("Translation failed: ${e.localizedMessage}", e)
        }
    }

    private suspend fun performTranslation(request: TranslationRequest): String {
        val sourceLang = if (request.sourceLanguage == "auto") {
            TranslateLanguage.ENGLISH // Fallback; ideally use language detection
        } else {
            request.sourceLanguage
        }
        val targetLang = request.targetLanguage

        val key = "${sourceLang}_${targetLang}"
        val translator = translatorCache.getOrPut(key) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(sourceLang)
                .setTargetLanguage(targetLang)
                .build()
            Translation.getClient(options)
        }

        // Ensure model is downloaded
        val conditions = DownloadConditions.Builder().build()
        translator.downloadModelIfNeeded(conditions).await()

        return translator.translate(request.text).await()
    }

    override suspend fun getCachedTranslation(
        text: String,
        sourceLang: String,
        targetLang: String
    ): TranslationResult? {
        return try {
            val key = buildCacheKey(text, sourceLang, targetLang)
            val cached = cacheDao.getCachedTranslation(key) ?: return null
            TranslationResult(
                originalText = cached.originalText,
                translatedText = cached.translatedText,
                sourceLanguage = cached.sourceLanguage,
                targetLanguage = cached.targetLanguage,
                timestamp = cached.timestamp
            )
        } catch (e: Exception) {
            Timber.e(e, "Cache lookup failed")
            null
        }
    }

    private suspend fun cacheTranslation(result: TranslationResult) {
        try {
            // Enforce max cache size
            val cacheSize = cacheDao.getCacheSize()
            if (cacheSize >= Constants.TRANSLATION_CACHE_SIZE) {
                cacheDao.deleteOldestEntries(10)
            }

            val key = buildCacheKey(result.originalText, result.sourceLanguage, result.targetLanguage)
            cacheDao.insertTranslation(
                TranslationCacheEntity(
                    cacheKey = key,
                    originalText = result.originalText,
                    translatedText = result.translatedText,
                    sourceLanguage = result.sourceLanguage,
                    targetLanguage = result.targetLanguage
                )
            )
        } catch (e: Exception) {
            Timber.e(e, "Failed to cache translation")
        }
    }

    override fun getSupportedLanguages(): List<Language> {
        return listOf(
            Language("af", "Afrikaans"),
            Language("ar", "Arabic"),
            Language("be", "Belarusian"),
            Language("bg", "Bulgarian"),
            Language("bn", "Bengali"),
            Language("ca", "Catalan"),
            Language("cs", "Czech"),
            Language("cy", "Welsh"),
            Language("da", "Danish"),
            Language("de", "German"),
            Language("el", "Greek"),
            Language("en", "English"),
            Language("eo", "Esperanto"),
            Language("es", "Spanish"),
            Language("et", "Estonian"),
            Language("fa", "Persian"),
            Language("fi", "Finnish"),
            Language("fr", "French"),
            Language("ga", "Irish"),
            Language("gl", "Galician"),
            Language("gu", "Gujarati"),
            Language("he", "Hebrew"),
            Language("hi", "Hindi"),
            Language("hr", "Croatian"),
            Language("ht", "Haitian Creole"),
            Language("hu", "Hungarian"),
            Language("id", "Indonesian"),
            Language("is", "Icelandic"),
            Language("it", "Italian"),
            Language("ja", "Japanese"),
            Language("ka", "Georgian"),
            Language("kn", "Kannada"),
            Language("ko", "Korean"),
            Language("lt", "Lithuanian"),
            Language("lv", "Latvian"),
            Language("mk", "Macedonian"),
            Language("mr", "Marathi"),
            Language("ms", "Malay"),
            Language("mt", "Maltese"),
            Language("nl", "Dutch"),
            Language("no", "Norwegian"),
            Language("pl", "Polish"),
            Language("pt", "Portuguese"),
            Language("ro", "Romanian"),
            Language("ru", "Russian"),
            Language("sk", "Slovak"),
            Language("sl", "Slovenian"),
            Language("sq", "Albanian"),
            Language("sr", "Serbian"),
            Language("sv", "Swedish"),
            Language("sw", "Swahili"),
            Language("ta", "Tamil"),
            Language("te", "Telugu"),
            Language("th", "Thai"),
            Language("tl", "Tagalog"),
            Language("tr", "Turkish"),
            Language("uk", "Ukrainian"),
            Language("ur", "Urdu"),
            Language("vi", "Vietnamese"),
            Language("zh", "Chinese"),
        )
    }

    override suspend fun downloadLanguageModel(languageCode: String): Flow<Resource<Unit>> = flow {
        emit(Resource.Loading)
        try {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(languageCode)
                .setTargetLanguage(TranslateLanguage.ENGLISH)
                .build()
            val translator = Translation.getClient(options)
            val conditions = DownloadConditions.Builder().build()
            translator.downloadModelIfNeeded(conditions).await()
            emit(Resource.Success(Unit))
        } catch (e: Exception) {
            Timber.e(e, "Failed to download language model: $languageCode")
            emit(Resource.Error("Download failed: ${e.localizedMessage}", e))
        }
    }

    override suspend fun deleteLanguageModel(languageCode: String) {
        try {
            val key1 = "${languageCode}_en"
            val key2 = "en_${languageCode}"
            translatorCache.remove(key1)?.close()
            translatorCache.remove(key2)?.close()
        } catch (e: Exception) {
            Timber.e(e, "Failed to delete language model: $languageCode")
        }
    }

    override suspend fun isLanguageModelDownloaded(languageCode: String): Boolean {
        return try {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(languageCode)
                .setTargetLanguage(TranslateLanguage.ENGLISH)
                .build()
            val translator = Translation.getClient(options)
            // Try to translate without downloading
            translator.translate("test").await()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun buildCacheKey(text: String, sourceLang: String, targetLang: String): String {
        return "${sourceLang}_${targetLang}_${text.hashCode()}"
    }
}
