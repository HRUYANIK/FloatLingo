package com.floatlingo.feature.translation

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.floatlingo.R
import com.floatlingo.data.model.TranslationMode
import timber.log.Timber

class TranslationOverlayManager(
    private val context: Context,
    private val windowManager: WindowManager
) {
    private var overlayView: View? = null
    private var continuousIndicatorView: View? = null

    private val overlayLayoutParams = WindowManager.LayoutParams().apply {
        type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        format = PixelFormat.TRANSLUCENT
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        width = WindowManager.LayoutParams.MATCH_PARENT
        height = WindowManager.LayoutParams.WRAP_CONTENT
        x = 0
        y = 100
    }

    fun showTranslation(originalText: String, translatedText: String, mode: TranslationMode) {
        hideTranslationOverlay()

        try {
            val inflater = LayoutInflater.from(context)
            val view = inflater.inflate(R.layout.view_translation_overlay, null)

            view.findViewById<TextView>(R.id.tv_original_text)?.text = originalText
            view.findViewById<TextView>(R.id.tv_translated_text)?.text = translatedText

            view.setOnClickListener { hideTranslationOverlay() }

            overlayView = view
            windowManager.addView(view, overlayLayoutParams)

            // Auto-dismiss for instant mode
            if (mode == TranslationMode.INSTANT) {
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    hideTranslationOverlay()
                }, 8000)
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to show translation overlay")
        }
    }

    fun hideTranslationOverlay() {
        try {
            overlayView?.let {
                if (it.parent != null) {
                    windowManager.removeView(it)
                }
            }
            overlayView = null
        } catch (e: Exception) {
            Timber.e(e, "Failed to hide translation overlay")
        }
    }

    fun showContinuousIndicator(show: Boolean) {
        if (show) {
            if (continuousIndicatorView?.parent != null) return
            try {
                val inflater = LayoutInflater.from(context)
                val view = inflater.inflate(R.layout.view_continuous_indicator, null)
                val params = WindowManager.LayoutParams().apply {
                    type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    } else {
                        @Suppress("DEPRECATION")
                        WindowManager.LayoutParams.TYPE_PHONE
                    }
                    flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    format = PixelFormat.TRANSLUCENT
                    gravity = Gravity.TOP or Gravity.END
                    width = WindowManager.LayoutParams.WRAP_CONTENT
                    height = WindowManager.LayoutParams.WRAP_CONTENT
                    x = 16
                    y = 100
                }
                continuousIndicatorView = view
                windowManager.addView(view, params)
            } catch (e: Exception) {
                Timber.e(e, "Failed to show continuous indicator")
            }
        } else {
            try {
                continuousIndicatorView?.let {
                    if (it.parent != null) windowManager.removeView(it)
                }
                continuousIndicatorView = null
            } catch (e: Exception) {
                Timber.e(e, "Failed to hide continuous indicator")
            }
        }
    }

    fun cleanup() {
        hideTranslationOverlay()
        showContinuousIndicator(false)
    }
}
