package com.floatlingo.core.utils

object Constants {
    // Service
    const val FLOATING_SERVICE_NOTIFICATION_ID = 1001
    const val FLOATING_SERVICE_CHANNEL_ID = "floatlingo_floating_channel"
    const val FLOATING_SERVICE_CHANNEL_NAME = "FloatLingo Floating Assistant"

    // MediaProjection
    const val SCREEN_CAPTURE_REQUEST_CODE = 2001
    const val MEDIA_PROJECTION_RESULT_CODE = "media_projection_result_code"
    const val MEDIA_PROJECTION_RESULT_DATA = "media_projection_result_data"

    // Intent Actions
    const val ACTION_START_FLOATING = "com.floatlingo.ACTION_START_FLOATING"
    const val ACTION_STOP_FLOATING = "com.floatlingo.ACTION_STOP_FLOATING"
    const val ACTION_INSTANT_TRANSLATE = "com.floatlingo.ACTION_INSTANT_TRANSLATE"
    const val ACTION_CONTINUOUS_TRANSLATE = "com.floatlingo.ACTION_CONTINUOUS_TRANSLATE"
    const val ACTION_STOP_CONTINUOUS = "com.floatlingo.ACTION_STOP_CONTINUOUS"

    // Translation modes
    const val MODE_INSTANT = "instant"
    const val MODE_CONTINUOUS = "continuous"
    const val MODE_SIMPLE = "simple"

    // Cache
    const val TRANSLATION_CACHE_SIZE = 100
    const val CONTINUOUS_INTERVAL_MS = 2000L
    const val OCR_TEXT_SIMILARITY_THRESHOLD = 0.85f

    // Character types
    const val CHARACTER_ROBOT = "robot"
    const val CHARACTER_CAT = "cat"
    const val CHARACTER_OWL = "owl"

    // Preferences keys
    const val PREF_SOURCE_LANGUAGE = "source_language"
    const val PREF_TARGET_LANGUAGE = "target_language"
    const val PREF_CHARACTER_TYPE = "character_type"
    const val PREF_FONT_SIZE = "font_size"
    const val PREF_THEME = "theme"
    const val PREF_OVERLAY_OPACITY = "overlay_opacity"
    const val PREF_FIRST_LAUNCH = "first_launch"

    // Default values
    const val DEFAULT_SOURCE_LANGUAGE = "auto"
    const val DEFAULT_TARGET_LANGUAGE = "tr"
    const val DEFAULT_CHARACTER = CHARACTER_ROBOT
    const val DEFAULT_FONT_SIZE = 16f
    const val DEFAULT_THEME = "system"
    const val DEFAULT_OVERLAY_OPACITY = 0.9f

    // Network
    const val API_TIMEOUT_SECONDS = 30L
}
