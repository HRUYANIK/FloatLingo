package com.floatlingo.data.source.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.floatlingo.core.utils.Constants
import com.floatlingo.data.model.AppSettings
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import timber.log.Timber
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "floatlingo_prefs")

@Singleton
class AppPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val SOURCE_LANGUAGE = stringPreferencesKey(Constants.PREF_SOURCE_LANGUAGE)
        val TARGET_LANGUAGE = stringPreferencesKey(Constants.PREF_TARGET_LANGUAGE)
        val CHARACTER_TYPE = stringPreferencesKey(Constants.PREF_CHARACTER_TYPE)
        val FONT_SIZE = floatPreferencesKey(Constants.PREF_FONT_SIZE)
        val THEME = stringPreferencesKey(Constants.PREF_THEME)
        val OVERLAY_OPACITY = floatPreferencesKey(Constants.PREF_OVERLAY_OPACITY)
        val FIRST_LAUNCH = booleanPreferencesKey(Constants.PREF_FIRST_LAUNCH)
    }

    val appSettings: Flow<AppSettings> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                Timber.e(exception, "Error reading preferences")
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            AppSettings(
                sourceLanguage = preferences[Keys.SOURCE_LANGUAGE] ?: Constants.DEFAULT_SOURCE_LANGUAGE,
                targetLanguage = preferences[Keys.TARGET_LANGUAGE] ?: Constants.DEFAULT_TARGET_LANGUAGE,
                characterType = preferences[Keys.CHARACTER_TYPE] ?: Constants.DEFAULT_CHARACTER,
                fontSize = preferences[Keys.FONT_SIZE] ?: Constants.DEFAULT_FONT_SIZE,
                theme = preferences[Keys.THEME] ?: Constants.DEFAULT_THEME,
                overlayOpacity = preferences[Keys.OVERLAY_OPACITY] ?: Constants.DEFAULT_OVERLAY_OPACITY
            )
        }

    val isFirstLaunch: Flow<Boolean> = context.dataStore.data
        .map { preferences -> preferences[Keys.FIRST_LAUNCH] ?: true }

    suspend fun updateSourceLanguage(language: String) {
        context.dataStore.edit { it[Keys.SOURCE_LANGUAGE] = language }
    }

    suspend fun updateTargetLanguage(language: String) {
        context.dataStore.edit { it[Keys.TARGET_LANGUAGE] = language }
    }

    suspend fun updateCharacterType(type: String) {
        context.dataStore.edit { it[Keys.CHARACTER_TYPE] = type }
    }

    suspend fun updateFontSize(size: Float) {
        context.dataStore.edit { it[Keys.FONT_SIZE] = size }
    }

    suspend fun updateTheme(theme: String) {
        context.dataStore.edit { it[Keys.THEME] = theme }
    }

    suspend fun updateOverlayOpacity(opacity: Float) {
        context.dataStore.edit { it[Keys.OVERLAY_OPACITY] = opacity }
    }

    suspend fun setFirstLaunchCompleted() {
        context.dataStore.edit { it[Keys.FIRST_LAUNCH] = false }
    }
}
