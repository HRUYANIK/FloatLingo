package com.floatlingo.feature.settings

import android.os.Bundle
import android.view.MenuItem
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.lifecycleScope
import com.floatlingo.R
import com.floatlingo.core.utils.Constants
import com.floatlingo.databinding.ActivitySettingsBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.settings)

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        // Character selection
        binding.cardRobot.setOnClickListener { viewModel.updateCharacterType(Constants.CHARACTER_ROBOT) }
        binding.cardCat.setOnClickListener { viewModel.updateCharacterType(Constants.CHARACTER_CAT) }
        binding.cardOwl.setOnClickListener { viewModel.updateCharacterType(Constants.CHARACTER_OWL) }

        // Theme selection
        binding.rgTheme.setOnCheckedChangeListener { _, checkedId ->
            val theme = when (checkedId) {
                R.id.rb_light -> "light"
                R.id.rb_dark -> "dark"
                else -> "system"
            }
            viewModel.updateTheme(theme)
            applyTheme(theme)
        }

        // Font size seekbar
        binding.sbFontSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val size = 12f + progress * 2f // 12-30sp range
                binding.tvFontSizeValue.text = "${size.toInt()}sp"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val size = 12f + (seekBar?.progress ?: 4) * 2f
                viewModel.updateFontSize(size)
            }
        })

        // Overlay opacity seekbar
        binding.sbOverlayOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val opacity = progress / 100f
                binding.tvOpacityValue.text = "${progress}%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val opacity = (seekBar?.progress ?: 90) / 100f
                viewModel.updateOverlayOpacity(opacity)
            }
        })

        // Source language
        binding.btnSourceLanguage.setOnClickListener {
            showLanguagePicker(isSource = true)
        }

        // Target language
        binding.btnTargetLanguage.setOnClickListener {
            showLanguagePicker(isSource = false)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.settings.collectLatest { settings ->
                // Update character selection
                val selectedCard = when (settings.characterType) {
                    Constants.CHARACTER_ROBOT -> binding.cardRobot
                    Constants.CHARACTER_CAT -> binding.cardCat
                    Constants.CHARACTER_OWL -> binding.cardOwl
                    else -> binding.cardRobot
                }
                listOf(binding.cardRobot, binding.cardCat, binding.cardOwl).forEach {
                    it.strokeWidth = if (it == selectedCard) 4 else 0
                }

                // Update theme radio
                val themeRes = when (settings.theme) {
                    "light" -> R.id.rb_light
                    "dark" -> R.id.rb_dark
                    else -> R.id.rb_system
                }
                binding.rgTheme.check(themeRes)

                // Update font size
                val progress = ((settings.fontSize - 12f) / 2f).toInt().coerceIn(0, 9)
                binding.sbFontSize.progress = progress
                binding.tvFontSizeValue.text = "${settings.fontSize.toInt()}sp"

                // Update opacity
                val opacityProgress = (settings.overlayOpacity * 100).toInt()
                binding.sbOverlayOpacity.progress = opacityProgress
                binding.tvOpacityValue.text = "${opacityProgress}%"

                // Update language buttons
                binding.btnSourceLanguage.text = settings.sourceLanguage.uppercase()
                binding.btnTargetLanguage.text = settings.targetLanguage.uppercase()
            }
        }

        lifecycleScope.launch {
            viewModel.errorMessage.collectLatest { error ->
                if (error != null) {
                    Toast.makeText(this@SettingsActivity, error, Toast.LENGTH_LONG).show()
                    viewModel.clearError()
                }
            }
        }
    }

    private fun applyTheme(theme: String) {
        val mode = when (theme) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    private fun showLanguagePicker(isSource: Boolean) {
        val dialog = com.floatlingo.feature.translation.LanguagePickerDialog(
            onLanguageSelected = { code ->
                if (isSource) viewModel.updateSourceLanguage(code)
                else viewModel.updateTargetLanguage(code)
            }
        )
        dialog.show(supportFragmentManager, "language_picker")
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
