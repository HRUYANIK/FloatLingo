package com.floatlingo.ui

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.lifecycleScope
import com.floatlingo.R
import com.floatlingo.core.utils.Constants
import com.floatlingo.core.utils.canDrawOverlays
import com.floatlingo.databinding.ActivityMainBinding
import com.floatlingo.feature.floating.FloatingCharacterService
import com.floatlingo.feature.permissions.PermissionSetupActivity
import com.floatlingo.feature.settings.SettingsActivity
import com.floatlingo.feature.translation.SimpleTranslateFragment
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            // Pass MediaProjection token to service
            val serviceIntent = Intent(this, FloatingCharacterService::class.java).apply {
                action = Constants.ACTION_START_FLOATING
                putExtra(Constants.MEDIA_PROJECTION_RESULT_CODE, result.resultCode)
                putExtra(Constants.MEDIA_PROJECTION_RESULT_DATA, result.data)
            }
            startService(serviceIntent)
        } else {
            Toast.makeText(this, getString(R.string.screen_capture_denied), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Apply theme before setting content
        lifecycleScope.launch {
            val settings = viewModel.getSettings()
            val mode = when (settings.theme) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
            AppCompatDelegate.setDefaultNightMode(mode)
        }

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        checkFirstLaunch()
        setupUI()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        when (intent?.getStringExtra("open_tab")) {
            "simple_translate" -> binding.bottomNav.selectedItemId = R.id.nav_translate
        }
    }

    private fun checkFirstLaunch() {
        lifecycleScope.launch {
            val isFirst = viewModel.isFirstLaunch()
            if (isFirst) {
                startActivity(Intent(this@MainActivity, PermissionSetupActivity::class.java))
                finish()
            }
        }
    }

    private fun setupUI() {
        // Bottom navigation
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    showFragment(HomeFragment())
                    true
                }
                R.id.nav_translate -> {
                    showFragment(SimpleTranslateFragment())
                    true
                }
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    false
                }
                else -> false
            }
        }

        // Default fragment
        if (supportFragmentManager.fragments.isEmpty()) {
            showFragment(HomeFragment())
        }

        // FAB - Start floating assistant
        binding.fabStartAssistant.setOnClickListener {
            startFloatingAssistant()
        }
    }

    private fun showFragment(fragment: androidx.fragment.app.Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    private fun startFloatingAssistant() {
        if (!canDrawOverlays()) {
            Toast.makeText(this, getString(R.string.overlay_permission_required), Toast.LENGTH_LONG).show()
            startActivity(Intent(this, PermissionSetupActivity::class.java))
            return
        }

        // Request screen capture permission
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_stop_service -> {
                FloatingCharacterService.stop(this)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
