package com.floatlingo.core.di

import android.content.Context
import androidx.room.Room
import com.floatlingo.data.source.local.FloatLingoDatabase
import com.floatlingo.data.source.local.TranslationCacheDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): FloatLingoDatabase {
        return Room.databaseBuilder(
            context,
            FloatLingoDatabase::class.java,
            FloatLingoDatabase.DATABASE_NAME
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    @Singleton
    fun provideTranslationCacheDao(database: FloatLingoDatabase): TranslationCacheDao {
        return database.translationCacheDao()
    }
}
