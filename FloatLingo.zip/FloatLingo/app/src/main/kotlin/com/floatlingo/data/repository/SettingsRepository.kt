package com.floatlingo.data.repository

import com.floatlingo.data.model.AppSettings
import com.floatlingo.data.source.local.AppPreferences
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface SettingsRepository {
    fun getAppSettings(): Flow<AppSettings>
    fun isFirstLaunch(): Flow<Boolean>
    suspend fun updateSourceLanguage(language: String)
    suspend fun updateTargetLanguage(language: String)
    suspend fun updateCharacterType(type: String)
    suspend fun updateFontSize(size: Float)
    suspend fun updateTheme(theme: String)
    suspend fun updateOverlayOpacity(opacity: Float)
    suspend fun setFirstLaunchCompleted()
}

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    private val preferences: AppPreferences
) : SettingsRepository {

    override fun getAppSettings(): Flow<AppSettings> = preferences.appSettings

    override fun isFirstLaunch(): Flow<Boolean> = preferences.isFirstLaunch

    override suspend fun updateSourceLanguage(language: String) {
        preferences.updateSourceLanguage(language)
    }

    override suspend fun updateTargetLanguage(language: String) {
        preferences.updateTargetLanguage(language)
    }

    override suspend fun updateCharacterType(type: String) {
        preferences.updateCharacterType(type)
    }

    override suspend fun updateFontSize(size: Float) {
        preferences.updateFontSize(size)
    }

    override suspend fun updateTheme(theme: String) {
        preferences.updateTheme(theme)
    }

    override suspend fun updateOverlayOpacity(opacity: Float) {
        preferences.updateOverlayOpacity(opacity)
    }

    override suspend fun setFirstLaunchCompleted() {
        preferences.setFirstLaunchCompleted()
    }
}
