package com.floatlingo.feature.translation

import androidx.lifecycle.viewModelScope
import com.floatlingo.core.base.BaseViewModel
import com.floatlingo.core.utils.Resource
import com.floatlingo.data.model.TranslationRequest
import com.floatlingo.data.model.TranslationResult
import com.floatlingo.data.repository.SettingsRepository
import com.floatlingo.data.repository.TranslationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class SimpleTranslateViewModel @Inject constructor(
    private val translationRepository: TranslationRepository,
    private val settingsRepository: SettingsRepository
) : BaseViewModel() {

    private val _translationResult = MutableStateFlow<TranslationResult?>(null)
    val translationResult: StateFlow<TranslationResult?> = _translationResult.asStateFlow()

    private val _sourceLanguage = MutableStateFlow("en")
    val sourceLanguage: StateFlow<String> = _sourceLanguage.asStateFlow()

    private val _targetLanguage = MutableStateFlow("tr")
    val targetLanguage: StateFlow<String> = _targetLanguage.asStateFlow()

    init {
        loadSettings()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            val settings = settingsRepository.getAppSettings().first()
            _sourceLanguage.value = settings.sourceLanguage
            _targetLanguage.value = settings.targetLanguage
        }
    }

    fun translate(text: String) {
        if (text.isBlank()) return

        viewModelScope.launch {
            setLoading(true)
            try {
                val request = TranslationRequest(
                    text = text,
                    sourceLanguage = _sourceLanguage.value,
                    targetLanguage = _targetLanguage.value
                )
                when (val result = translationRepository.translate(request)) {
                    is Resource.Success -> {
                        _translationResult.value = result.data
                        setError(null)
                    }
                    is Resource.Error -> {
                        setError(result.message)
                        Timber.e(result.throwable, "Translation error")
                    }
                    is Resource.Loading -> {}
                }
            } finally {
                setLoading(false)
            }
        }
    }

    fun swapLanguages() {
        val temp = _sourceLanguage.value
        _sourceLanguage.value = _targetLanguage.value
        _targetLanguage.value = temp

        // Re-translate if there's a result
        _translationResult.value?.translatedText?.let { translate(it) }
    }

    fun updateSourceLanguage(code: String) {
        _sourceLanguage.value = code
        viewModelScope.launch {
            settingsRepository.updateSourceLanguage(code)
        }
    }

    fun updateTargetLanguage(code: String) {
        _targetLanguage.value = code
        viewModelScope.launch {
            settingsRepository.updateTargetLanguage(code)
        }
    }

    fun clearTranslation() {
        _translationResult.value = null
    }
}
