package com.floatlingo.ui

import androidx.lifecycle.ViewModel
import com.floatlingo.data.model.AppSettings
import com.floatlingo.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.first
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    suspend fun isFirstLaunch(): Boolean {
        return settingsRepository.isFirstLaunch().first()
    }

    suspend fun getSettings(): AppSettings {
        return settingsRepository.getAppSettings().first()
    }
}
