package com.floatlingo.data.repository

import com.floatlingo.core.utils.Resource
import com.floatlingo.data.model.Language
import com.floatlingo.data.model.TranslationRequest
import com.floatlingo.data.model.TranslationResult
import kotlinx.coroutines.flow.Flow

interface TranslationRepository {
    suspend fun translate(request: TranslationRequest): Resource<TranslationResult>
    suspend fun getCachedTranslation(text: String, sourceLang: String, targetLang: String): TranslationResult?
    fun getSupportedLanguages(): List<Language>
    suspend fun downloadLanguageModel(languageCode: String): Flow<Resource<Unit>>
    suspend fun deleteLanguageModel(languageCode: String)
    suspend fun isLanguageModelDownloaded(languageCode: String): Boolean
}
