package com.floatlingo.data.source.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.floatlingo.data.model.TranslationCacheEntity

@Database(
    entities = [TranslationCacheEntity::class],
    version = 1,
    exportSchema = false
)
abstract class FloatLingoDatabase : RoomDatabase() {
    abstract fun translationCacheDao(): TranslationCacheDao

    companion object {
        const val DATABASE_NAME = "floatlingo_db"
    }
}
