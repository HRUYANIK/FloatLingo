package com.floatlingo.data.source.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.floatlingo.data.model.TranslationCacheEntity

@Dao
interface TranslationCacheDao {

    @Query("SELECT * FROM translation_cache WHERE cacheKey = :key LIMIT 1")
    suspend fun getCachedTranslation(key: String): TranslationCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTranslation(entity: TranslationCacheEntity)

    @Query("DELETE FROM translation_cache WHERE timestamp < :expiryTime")
    suspend fun deleteExpiredCache(expiryTime: Long)

    @Query("SELECT COUNT(*) FROM translation_cache")
    suspend fun getCacheSize(): Int

    @Query("DELETE FROM translation_cache WHERE cacheKey IN (SELECT cacheKey FROM translation_cache ORDER BY timestamp ASC LIMIT :count)")
    suspend fun deleteOldestEntries(count: Int)

    @Query("DELETE FROM translation_cache")
    suspend fun clearAll()
}
