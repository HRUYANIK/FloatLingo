package com.floatlingo.feature.permissions

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.floatlingo.R
import com.floatlingo.core.utils.canDrawOverlays
import com.floatlingo.core.utils.hasPermission
import com.floatlingo.databinding.ActivityPermissionSetupBinding
import com.floatlingo.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@AndroidEntryPoint
class PermissionSetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionSetupBinding

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { updatePermissionStates() }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { updatePermissionStates() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        updatePermissionStates()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStates()
    }

    private fun setupUI() {
        // Draw over apps permission
        binding.btnGrantOverlay.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }

        // Microphone permission
        binding.btnGrantMicrophone.setOnClickListener {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        // Continue button
        binding.btnContinue.setOnClickListener {
            navigateToMain()
        }

        // Skip optional permissions
        binding.btnSkip.setOnClickListener {
            navigateToMain()
        }
    }

    private fun updatePermissionStates() {
        val overlayGranted = canDrawOverlays()
        val micGranted = hasPermission(Manifest.permission.RECORD_AUDIO)

        // Overlay permission (required)
        binding.ivOverlayStatus.setImageResource(
            if (overlayGranted) R.drawable.ic_check_circle else R.drawable.ic_pending
        )
        binding.btnGrantOverlay.visibility = if (overlayGranted) View.GONE else View.VISIBLE
        binding.tvOverlayGranted.visibility = if (overlayGranted) View.VISIBLE else View.GONE

        // Microphone permission (optional)
        binding.ivMicStatus.setImageResource(
            if (micGranted) R.drawable.ic_check_circle else R.drawable.ic_pending
        )
        binding.btnGrantMicrophone.visibility = if (micGranted) View.GONE else View.VISIBLE
        binding.tvMicGranted.visibility = if (micGranted) View.VISIBLE else View.GONE

        // Enable continue only if overlay is granted (required)
        binding.btnContinue.isEnabled = overlayGranted
        binding.btnContinue.alpha = if (overlayGranted) 1f else 0.5f

        // Auto-navigate if all permissions are granted
        if (overlayGranted && micGranted) {
            lifecycleScope.launch {
                delay(800)
                navigateToMain()
            }
        }
    }

    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
