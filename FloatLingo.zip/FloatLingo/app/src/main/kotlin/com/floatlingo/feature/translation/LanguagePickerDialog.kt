package com.floatlingo.feature.translation

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.floatlingo.R
import com.floatlingo.data.model.Language
import com.floatlingo.databinding.DialogLanguagePickerBinding
import com.floatlingo.databinding.ItemLanguageBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class LanguagePickerDialog(
    private val onLanguageSelected: (String) -> Unit
) : BottomSheetDialogFragment() {

    @Inject lateinit var translationRepository: com.floatlingo.data.repository.TranslationRepository

    private var _binding: DialogLanguagePickerBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: LanguageAdapter
    private var allLanguages: List<Language> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogLanguagePickerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = LanguageAdapter { language ->
            onLanguageSelected(language.code)
            dismiss()
        }

        binding.rvLanguages.layoutManager = LinearLayoutManager(context)
        binding.rvLanguages.adapter = adapter

        allLanguages = translationRepository.getSupportedLanguages()
        adapter.submitList(allLanguages)

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.lowercase() ?: ""
                val filtered = if (query.isBlank()) allLanguages
                else allLanguages.filter {
                    it.displayName.lowercase().contains(query) || it.code.lowercase().contains(query)
                }
                adapter.submitList(filtered)
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class LanguageAdapter(
    private val onLanguageClicked: (Language) -> Unit
) : ListAdapter<Language, LanguageAdapter.ViewHolder>(LanguageDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemLanguageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemLanguageBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(language: Language) {
            binding.tvLanguageName.text = language.displayName
            binding.tvLanguageCode.text = language.code.uppercase()
            binding.root.setOnClickListener { onLanguageClicked(language) }
        }
    }
}

class LanguageDiffCallback : DiffUtil.ItemCallback<Language>() {
    override fun areItemsTheSame(oldItem: Language, newItem: Language): Boolean =
        oldItem.code == newItem.code

    override fun areContentsTheSame(oldItem: Language, newItem: Language): Boolean =
        oldItem == newItem
}
