package com.floatlingo.feature.settings

import androidx.lifecycle.viewModelScope
import com.floatlingo.core.base.BaseViewModel
import com.floatlingo.core.utils.Resource
import com.floatlingo.data.model.AppSettings
import com.floatlingo.data.model.Language
import com.floatlingo.data.repository.SettingsRepository
import com.floatlingo.data.repository.TranslationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val translationRepository: TranslationRepository
) : BaseViewModel() {

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _languages = MutableStateFlow<List<Language>>(emptyList())
    val languages: StateFlow<List<Language>> = _languages.asStateFlow()

    private val _downloadStatus = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val downloadStatus: StateFlow<Map<String, Boolean>> = _downloadStatus.asStateFlow()

    init {
        observeSettings()
        loadLanguages()
    }

    private fun observeSettings() {
        viewModelScope.launch {
            settingsRepository.getAppSettings().collect { settings ->
                _settings.value = settings
            }
        }
    }

    private fun loadLanguages() {
        _languages.value = translationRepository.getSupportedLanguages()
    }

    fun updateSourceLanguage(code: String) {
        viewModelScope.launch {
            settingsRepository.updateSourceLanguage(code)
        }
    }

    fun updateTargetLanguage(code: String) {
        viewModelScope.launch {
            settingsRepository.updateTargetLanguage(code)
        }
    }

    fun updateCharacterType(type: String) {
        viewModelScope.launch {
            settingsRepository.updateCharacterType(type)
        }
    }

    fun updateFontSize(size: Float) {
        viewModelScope.launch {
            settingsRepository.updateFontSize(size)
        }
    }

    fun updateTheme(theme: String) {
        viewModelScope.launch {
            settingsRepository.updateTheme(theme)
        }
    }

    fun updateOverlayOpacity(opacity: Float) {
        viewModelScope.launch {
            settingsRepository.updateOverlayOpacity(opacity)
        }
    }

    fun downloadLanguageModel(languageCode: String) {
        viewModelScope.launch {
            translationRepository.downloadLanguageModel(languageCode)
                .collect { resource ->
                    when (resource) {
                        is Resource.Loading -> {
                            _downloadStatus.value = _downloadStatus.value.toMutableMap().apply {
                                put(languageCode, false)
                            }
                        }
                        is Resource.Success -> {
                            _downloadStatus.value = _downloadStatus.value.toMutableMap().apply {
                                put(languageCode, true)
                            }
                        }
                        is Resource.Error -> {
                            Timber.e("Failed to download: $languageCode - ${resource.message}")
                            setError(resource.message)
                        }
                    }
                }
        }
    }
}
